//
// Created by fenix on 2/25/20.
//

#ifndef LAB_2_PARALLEL_INTEGRATION_LANGERMANN_F_H
#define LAB_2_PARALLEL_INTEGRATION_LANGERMANN_F_H

#include "func_args.h"

double langermann_f(const point &p, const f_params &conf);

#endif //LAB_2_PARALLEL_INTEGRATION_LANGERMANN_F_H
